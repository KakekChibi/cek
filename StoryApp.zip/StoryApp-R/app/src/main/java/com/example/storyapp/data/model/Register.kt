package com.example.storyapp.data.model

data class Register(
	val error: Boolean,
	val message: String
)

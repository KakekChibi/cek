package com.example.storyapp.data.viewmodel

import android.content.Context
import android.util.Log
import android.view.View
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import androidx.paging.liveData
import com.example.storyapp.R
import com.example.storyapp.data.model.Story
import com.example.storyapp.data.model.StoryList
import com.example.storyapp.data.model.StoryUpload
import com.example.storyapp.data.repository.remote.ApiService
import com.example.storyapp.data.repository.remote.QuotePagingSource
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class StoryViewModel(val context: Context, private val apiService: ApiService) : ViewModel() {
    var loading = MutableLiveData(View.GONE)
    var isSuccessUploadStory = MutableLiveData(false)
    val storyList = MutableLiveData<List<Story>>()
    var error = MutableLiveData("")
    private val TAG = StoryViewModel::class.simpleName



    fun loadStoryData(token: String) {
        loading.postValue(View.VISIBLE)
        val client = apiService.getStoryList(token, 30)
        client.enqueue(object : Callback<StoryList> {
            override fun onResponse(call: Call<StoryList>, response: Response<StoryList>) {
                if (response.isSuccessful) {
                    val stories = response.body()?.listStory ?: emptyList()
                    Log.d("StoryViewModel", "Fetched stories: $stories")
                    storyList.postValue(stories)
                } else {
                    if (response.code() == 401) {
                        error.postValue(context.getString(R.string.API_error_header_token))
                    } else {
                        error.postValue("ERROR ${response.code()} : ${response.message()}")
                    }
                }
                loading.postValue(View.GONE)
            }

            override fun onFailure(call: Call<StoryList>, t: Throwable) {
                loading.postValue(View.GONE)
                Log.e(TAG, "onFailure Call: ${t.message}")
                error.postValue("${context.getString(R.string.API_error_fetch_data)} : ${t.message}")
            }
        })
    }

    fun uploadNewStory(token: String, image: File, description: String) {
        loading.postValue(View.VISIBLE)
        val storyDescription = description.toRequestBody("text/plain".toMediaType())
        val requestImageFile = image.asRequestBody("image/jpeg".toMediaTypeOrNull())
        val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
            "photo",
            image.name,
            requestImageFile
        )
        val client = apiService.doUploadImage(token, imageMultipart, storyDescription)
        client.enqueue(object : Callback<StoryUpload> {
            override fun onResponse(call: Call<StoryUpload>, response: Response<StoryUpload>) {
                when (response.code()) {
                    401 -> error.postValue(context.getString(R.string.API_error_header_token))
                    413 -> error.postValue(context.getString(R.string.API_error_large_payload))
                    201 -> isSuccessUploadStory.postValue(true)
                    else -> error.postValue("Error ${response.code()} : ${response.message()}")
                }
                loading.postValue(View.GONE)
            }

            override fun onFailure(call: Call<StoryUpload>, t: Throwable) {
                loading.postValue(View.GONE)
                Log.e(TAG, "onFailure Call: ${t.message}")
                error.postValue("${context.getString(R.string.API_error_send_payload)} : ${t.message}")
            }
        })
    }

    fun getPagedStory(getToken: () -> String): LiveData<PagingData<Story>> {
        val pagingSourceFactory = { QuotePagingSource(apiService, getToken()) }
        return Pager(
            config = PagingConfig(
                pageSize = 20, // Sesuaikan dengan jumlah item per halaman yang Anda inginkan
                enablePlaceholders = false
            ),
            pagingSourceFactory = pagingSourceFactory
        ).liveData.cachedIn(viewModelScope).also {  Log.d("StoryViewModel", "PagingData LiveData created") }
    }
}

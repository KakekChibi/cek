//package com.example.storyapp.data.repository.remote
//
//import android.content.Context
//import android.content.SharedPreferences
//
//object PreferenceHelper {
//    private const val PREFS_NAME = "storyAppPrefs"
//    private const val TOKEN = "token"
//
//    fun saveToken(context: Context, token: String) {
//        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
//        val editor: SharedPreferences.Editor = prefs.edit()
//        editor.putString(TOKEN, token)
//        editor.apply()
//    }
//
//    fun getToken(context: Context): String? {
//        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
//        return prefs.getString(TOKEN, null)
//    }
//
//    fun clearToken(context: Context) {
//        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
//        val editor: SharedPreferences.Editor = prefs.edit()
//        editor.remove(TOKEN)
//        editor.apply()
//    }
//}
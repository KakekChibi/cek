package com.example.storyapp.data.model

data class User(
    val userId: String,
    val name: String,
    val token: String
)
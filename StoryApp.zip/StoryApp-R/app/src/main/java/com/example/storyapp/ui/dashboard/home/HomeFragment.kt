package com.example.storyapp.ui.dashboard.home

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.storyapp.R
import com.example.storyapp.data.repository.remote.ApiConfig
import com.example.storyapp.data.viewmodel.SettingViewModel
import com.example.storyapp.data.viewmodel.StoryViewModel
import com.example.storyapp.data.viewmodel.ViewModelStoryFactory
import com.example.storyapp.data.viewmodel.ViewModelSettingFactory
import com.example.storyapp.databinding.FragmentHomeBinding
import com.example.storyapp.ui.dashboard.MainActivity
import com.example.storyapp.ui.maps.MapsFragment
import com.example.storyapp.utils.Constanta
import com.example.storyapp.utils.Helper
import com.example.storyapp.utils.SettingPreferences
import com.example.storyapp.utils.dataStore
import kotlinx.coroutines.launch
import java.util.*
import kotlin.concurrent.schedule

class HomeFragment : Fragment(), SwipeRefreshLayout.OnRefreshListener {

    private lateinit var viewModel: StoryViewModel
    private lateinit var binding: FragmentHomeBinding
    private val rvAdapter = HomeAdapter()
    private var tempToken = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        viewModel = ViewModelProvider(
            this,
            ViewModelStoryFactory((activity as MainActivity), ApiConfig.getApiService())
        )[StoryViewModel::class.java]
        val pref = SettingPreferences.getInstance((activity as MainActivity).dataStore)
        val settingViewModel =
            ViewModelProvider(this, ViewModelSettingFactory(pref))[SettingViewModel::class.java]

        // Amati token pengguna
        settingViewModel.getUserPreferences(Constanta.UserPreferences.UserToken.name)
            .observe(viewLifecycleOwner) { token ->
                tempToken = "Bearer $token"
                Log.d("HomeFragment", "Token: $tempToken")
                viewModel.loadStoryData(tempToken)

                // Amati data story setelah token diperoleh
                viewModel.getPagedStory(tempToken).observe(viewLifecycleOwner) { pagingData ->
                    lifecycleScope.launch {
                        rvAdapter.submitData(pagingData)
                    }
                }
            }



        (activity as AppCompatActivity).setSupportActionBar(binding.toolbar)

        // Set up RecyclerView
        binding.rvStory.apply {
            setHasFixedSize(true)
            layoutManager = LinearLayoutManager(context)
            adapter = rvAdapter
            isNestedScrollingEnabled = false
        }

        // Observe the loading state
//        viewModel.loading.observe(viewLifecycleOwner) { visibility ->
//            binding.loading.root.visibility = visibility
//        }

        // Observe errors
        viewModel.error.observe(viewLifecycleOwner) { errorMessage ->
            if (errorMessage.isNotEmpty()) {
                Helper.showDialogInfo(requireContext(), errorMessage)
            }
        }

        binding.swipeRefresh.setOnRefreshListener(this)

        return binding.root
    }

    override fun onRefresh() {
        binding.swipeRefresh.isRefreshing = true
        viewModel.loadStoryData(tempToken)
        Timer().schedule(2000) {
            activity?.runOnUiThread {
                binding.swipeRefresh.isRefreshing = false
            }
        }
//        binding.nestedScrollView.smoothScrollTo(0, 0)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.activity_main_toolbar, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.navigation_map -> {
                navigateToMapsFragment()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun navigateToMapsFragment() {
        val mapsFragment = MapsFragment(tempToken)
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.container, mapsFragment)
            .addToBackStack(null)
            .commit()
    }
}
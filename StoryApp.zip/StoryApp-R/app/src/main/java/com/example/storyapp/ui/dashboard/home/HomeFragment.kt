package com.example.storyapp.ui.dashboard.home

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.storyapp.R
import com.example.storyapp.data.repository.remote.ApiConfig
import com.example.storyapp.data.viewmodel.SettingViewModel
import com.example.storyapp.data.viewmodel.StoryViewModel
import com.example.storyapp.data.viewmodel.ViewModelSettingFactory
import com.example.storyapp.data.viewmodel.ViewModelStoryFactory
import com.example.storyapp.databinding.FragmentHomeBinding
import com.example.storyapp.ui.dashboard.MainActivity
import com.example.storyapp.ui.maps.MapsFragment
import com.example.storyapp.utils.Constanta
import com.example.storyapp.utils.Helper
import com.example.storyapp.utils.SettingPreferences
import com.example.storyapp.utils.dataStore
import kotlinx.coroutines.launch
import java.util.*
import kotlin.concurrent.schedule

class HomeFragment : Fragment(), SwipeRefreshLayout.OnRefreshListener {

    private lateinit var viewModel: StoryViewModel
    private lateinit var binding: FragmentHomeBinding
    private val rvAdapter = HomeAdapter()
    private var tempToken: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        viewModel = ViewModelProvider(
            this,
            ViewModelStoryFactory((activity as MainActivity), ApiConfig.getApiService())
        )[StoryViewModel::class.java]

        val pref = SettingPreferences.getInstance((activity as MainActivity).dataStore)
        val settingViewModel = ViewModelProvider(
            this,
            ViewModelSettingFactory(pref)
        )[SettingViewModel::class.java]

        settingViewModel.getUserPreferences(Constanta.UserPreferences.UserToken.name)
            .observe(viewLifecycleOwner) { token ->
                if (token != null) {
                    tempToken = if (token.startsWith("Bearer ")) token else "Bearer $token"
                    Log.d("HomeFragment", "Token retrieved: $tempToken")
                    tempToken?.let {
                        Log.d("HomeFragment", "Calling observePagedStories with token: $it")
                        observePagedStories { it }
                    }
                } else {
                    Log.e("HomeFragment", "Token is null!")
                }
            }

        (activity as AppCompatActivity).setSupportActionBar(binding.toolbar)

        binding.rvStory.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = rvAdapter
            isNestedScrollingEnabled = false
        }

        viewModel.error.observe(viewLifecycleOwner) { errorMessage ->
            if (errorMessage.isNotEmpty()) {
                Helper.showDialogInfo(requireContext(), errorMessage)
            }
        }

        binding.swipeRefresh.setOnRefreshListener(this)

        return binding.root
    }

    private fun observePagedStories(getToken: () -> String) {
        viewModel.getPagedStory(getToken).observe(viewLifecycleOwner) { pagingData ->
            Log.d("HomeFragment", "PagingData received: $pagingData")
            lifecycleScope.launch {
                rvAdapter.submitData(pagingData)
                Log.d("HomeFragment", "Data submitted to adapter")
            }
        }
    }

    override fun onRefresh() {
        binding.swipeRefresh.isRefreshing = true
        tempToken?.let {
            observePagedStories { it }
        }
        Timer().schedule(2000) {
            activity?.runOnUiThread {
                binding.swipeRefresh.isRefreshing = false
            }
        }
//        binding.nestedScrollView.smoothScrollTo(0, 0)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.activity_main_toolbar, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.navigation_map -> {
                navigateToMapsFragment()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun navigateToMapsFragment() {
        tempToken?.let {
            val mapsFragment = MapsFragment(it)
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.container, mapsFragment)
                .addToBackStack(null)
                .commit()
        }
    }
}
package com.example.storyapp

import com.example.storyapp.data.model.Story
import com.example.storyapp.data.model.StoryList

object DataDummy {
    fun generateDummyStoryResponse(): StoryList {
        val stories = mutableListOf<Story>()
        for (i in 1..10) {
            val story = Story(
                id = "story-$i",
                name = "User $i",
                description = "Description $i",
                photoUrl = "https://example.com/photo/$i.jpg",
                createdAt = "2021-09-03T14:00:00Z"
            )
            stories.add(story)
        }
        return StoryList(listStory = stories)    }
}

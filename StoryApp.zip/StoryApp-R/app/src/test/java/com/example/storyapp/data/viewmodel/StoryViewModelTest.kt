    package com.example.storyapp.data.viewmodel

    import android.content.Context
    import androidx.arch.core.executor.testing.InstantTaskExecutorRule
    import com.example.storyapp.data.model.Story
    import com.example.storyapp.data.model.StoryList
    import com.example.storyapp.data.repository.remote.ApiService
    import com.example.storyapp.getOrAwaitValue
    import kotlinx.coroutines.ExperimentalCoroutinesApi
    import kotlinx.coroutines.test.runTest
    import org.junit.Assert.*
    import org.junit.Before
    import org.junit.Rule
    import org.junit.Test
    import org.junit.runner.RunWith
    import org.mockito.Mock
    import org.mockito.Mockito.*
    import org.mockito.junit.MockitoJUnitRunner
    import retrofit2.Call
    import retrofit2.Callback
    import retrofit2.Response

    @ExperimentalCoroutinesApi
    @RunWith(MockitoJUnitRunner::class)
    class StoryViewModelTest {
        @get:Rule
        val instantExecutorRule = InstantTaskExecutorRule()

        @Mock
        private lateinit var apiService: ApiService

        @Mock
        private lateinit var context: Context

        private lateinit var viewModel: StoryViewModel


        @Before
        fun setup() {
            viewModel = StoryViewModel(context, apiService)
        }

        @Test
        fun `when Load Story Data Should Return Success`() = runTest {
            val expectedStories = listOf(Story("1", "name", "description", "photoUrl", null, "id", null))
            val storyListResponse = StoryList(expectedStories)
            val call = mock(Call::class.java) as Call<StoryList>

            `when`(apiService.getStoryList(anyString(), anyInt())).thenReturn(call)

            doAnswer {
                val callback: Callback<StoryList> = it.getArgument(0)
                callback.onResponse(call, Response.success(storyListResponse))
            }.`when`(call).enqueue(any())

            val viewModel = StoryViewModel(context, apiService)
            viewModel.loadStoryData("token")

            val actualStories = viewModel.storyList.getOrAwaitValue()
            assertNotNull(actualStories)
            assertEquals(expectedStories.size, actualStories.size)
            assertEquals(expectedStories[0], actualStories[0])
        }

        @Test
        fun `when Load Story Data Should Return Empty List`() = runTest {
            val storyListResponse = StoryList(emptyList())
            val call = mock(Call::class.java) as Call<StoryList>

            `when`(apiService.getStoryList(anyString(), anyInt())).thenReturn(call)

            doAnswer {
                val callback: Callback<StoryList> = it.getArgument(0)
                callback.onResponse(call, Response.success(storyListResponse))
            }.`when`(call).enqueue(any())

            val viewModel = StoryViewModel(context, apiService)
            viewModel.loadStoryData("token")

            val actualStories = viewModel.storyList.getOrAwaitValue()
            assertNotNull(actualStories)
            assertTrue(actualStories.isEmpty())
        }


    }

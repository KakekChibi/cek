package com.example.storyapp.data.viewmodel

import android.content.Context
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.paging.AsyncPagingDataDiffer
import androidx.paging.PagingData
import androidx.paging.PagingSource
import androidx.paging.PagingState
import androidx.recyclerview.widget.ListUpdateCallback
import com.example.storyapp.DataDummy
import com.example.storyapp.MainDispatcherRule
import com.example.storyapp.data.model.Story
import com.example.storyapp.data.model.StoryList
import com.example.storyapp.data.repository.remote.ApiService
import com.example.storyapp.getOrAwaitValue
import com.example.storyapp.ui.dashboard.home.HomeAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.junit.MockitoJUnitRunner
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.concurrent.TimeUnit

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class StoryViewModelTest {
    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    @Mock
    private lateinit var apiService: ApiService

    @Mock
    private lateinit var context: Context

    private lateinit var viewModel: StoryViewModel

    @Before
    fun setup() {
        viewModel = StoryViewModel(context, apiService)
    }

    @Test
    fun `getPagedStory returns PagingData`() = runTest {
        val dummyStory = DataDummy.generateDummyStoryResponse().listStory
        val storyListResponse = StoryList(dummyStory)
        val call = mock(Call::class.java) as Call<StoryList>

        `when`(apiService.getStoryList(anyString(), anyInt())).thenReturn(call)

        doAnswer {
            val callback: Callback<StoryList> = it.getArgument(0)
            callback.onResponse(call, Response.success(storyListResponse))
        }.`when`(call).enqueue(any())

        val getToken: () -> String = { "token" }
        val liveData = viewModel.getPagedStory(getToken)
        val actualPagingData: PagingData<Story> = liveData.getOrAwaitValue(time = 5, timeUnit = TimeUnit.SECONDS)

        assertNotNull(actualPagingData)

        // Use AsyncPagingDataDiffer to submit the PagingData and verify the contents
        val differ = AsyncPagingDataDiffer(
            diffCallback = HomeAdapter.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            mainDispatcher = Dispatchers.Main
        )
        differ.submitData(actualPagingData)

        advanceUntilIdle() // Wait for all coroutines to finish

        assertEquals(dummyStory.size, differ.snapshot().size)
        assertEquals(dummyStory[0], differ.snapshot()[0])
    }

    @Test
    fun `when Load Story Data Should Return Empty List`() = runTest {
        val storyListResponse = StoryList(emptyList())
        val call = mock(Call::class.java) as Call<StoryList>

        `when`(apiService.getStoryList(anyString(), anyInt())).thenReturn(call)

        doAnswer {
            val callback: Callback<StoryList> = it.getArgument(0)
            callback.onResponse(call, Response.success(storyListResponse))
        }.`when`(call).enqueue(any())

        viewModel.loadStoryData("token")

        val actualStories = viewModel.storyList.getOrAwaitValue()
        assertNotNull(actualStories)
        assertTrue(actualStories.isEmpty())
    }

    private val noopListUpdateCallback = object : ListUpdateCallback {
        override fun onInserted(position: Int, count: Int) = Unit
        override fun onRemoved(position: Int, count: Int) = Unit
        override fun onMoved(fromPosition: Int, toPosition: Int) = Unit
        override fun onChanged(position: Int, count: Int, payload: Any?) = Unit
    }

    class StoryPagingSource : PagingSource<Int, Story>() {
        override fun getRefreshKey(state: PagingState<Int, Story>): Int? = null

        override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Story> {
            val dummyStory = DataDummy.generateDummyStoryResponse().listStory
            return LoadResult.Page(
                data = dummyStory,
                prevKey = null,
                nextKey = if (dummyStory.isEmpty()) null else 1
            )
        }
    }
}

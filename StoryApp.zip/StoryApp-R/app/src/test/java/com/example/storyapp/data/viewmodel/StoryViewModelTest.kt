package com.example.storyapp.data.viewmodel

import android.content.Context
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.paging.AsyncPagingDataDiffer
import androidx.paging.PagingData
import androidx.recyclerview.widget.ListUpdateCallback
import com.example.storyapp.MainDispatcherRule
import com.example.storyapp.data.model.Story
import com.example.storyapp.data.model.StoryList
import com.example.storyapp.data.repository.remote.ApiService
import com.example.storyapp.getOrAwaitValue
import com.example.storyapp.ui.dashboard.home.HomeAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.lenient
import org.mockito.junit.MockitoJUnitRunner
import retrofit2.Call
import retrofit2.Response

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class StoryViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val mainDispatcherRules = MainDispatcherRule()

    @Mock
    private lateinit var context: Context

    @Mock
    private lateinit var apiService: ApiService

    @Test
    fun whenGetPagedStoryEmptyShouldReturnNoData() = runTest {
        val data: PagingData<Story> = PagingData.from(emptyList())
        val expectedStories = MutableLiveData<PagingData<Story>>()
        expectedStories.value = data

        // Mengatur respons yang valid
        val mockedCall = Mockito.mock(Call::class.java) as Call<StoryList>
        val response = Response.success(StoryList(emptyList(), error = false, ""))

        // Menambahkan penanganan untuk respons null
        lenient().`when`(mockedCall.execute()).thenReturn(response)
        lenient().`when`(apiService.getStoryList(Mockito.anyString(), Mockito.anyInt())).thenReturn(mockedCall)

        // Melakukan pengujian
        val storyViewModel = StoryViewModel(context, apiService)
        val actualStories: PagingData<Story> = storyViewModel.getPagedStory { "Bearer token" }.getOrAwaitValue()

        // Menambahkan pengecekan respons null sebelum memanggil isSuccessful()
        if (response != null && response.isSuccessful) {
            val differ = AsyncPagingDataDiffer(
                diffCallback = HomeAdapter.DIFF_CALLBACK,
                updateCallback = noopListUpdateCallback,
                mainDispatcher = Dispatchers.Main,
            )
            differ.submitData(actualStories)

            assertEquals(0, differ.snapshot().size)
        } else {
            // Jika respons null, tes gagal
            fail("Response is null or unsuccessful")
        }
    }

    val noopListUpdateCallback = object : ListUpdateCallback {
        override fun onInserted(position: Int, count: Int) {}
        override fun onRemoved(position: Int, count: Int) {}
        override fun onMoved(fromPosition: Int, toPosition: Int) {}
        override fun onChanged(position: Int, count: Int, payload: Any?) {}
    }
}
package com.example.storyapp.data.viewmodel

import android.content.Context
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.paging.AsyncPagingDataDiffer
import androidx.paging.PagingData
import androidx.recyclerview.widget.ListUpdateCallback
import com.example.storyapp.LiveDataTestUtil.getOrAwaitValue
import com.example.storyapp.MainDispatcherRule
import com.example.storyapp.DataDummy
import com.example.storyapp.data.model.Story
import com.example.storyapp.data.model.StoryList
import com.example.storyapp.data.repository.remote.ApiService
import com.example.storyapp.ui.dashboard.home.HomeAdapter
import kotlinx.coroutines.*
import kotlinx.coroutines.test.runTest
import org.junit.Assert
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class StoryViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val mainDispatcherRules = MainDispatcherRule()

    @Mock
    private lateinit var apiService: ApiService

    @Mock
    private lateinit var context: Context

    @Test
    fun `when Get Stories Empty Should Return No Data`() = runTest {
        val data: PagingData<Story> = PagingData.from(emptyList())
        val tempToken = "Bearer dummyToken"
        val expectedStories = MutableLiveData<PagingData<Story>>()
        expectedStories.value = data

        Mockito.`when`(apiService.getStories(tempToken, 1, 20)).thenReturn(StoryList(emptyList()))

        val mainViewModel = StoryViewModel(context, apiService)
        val actualStories = mainViewModel.getPagedStory { tempToken }

        val differ = AsyncPagingDataDiffer(
            diffCallback = HomeAdapter.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            mainDispatcher = Dispatchers.Main,
            workerDispatcher = Dispatchers.IO
        )

        val observer = Observer<PagingData<Story>> { pagingData ->
            GlobalScope.launch(Dispatchers.Main) {
                differ.submitData(pagingData)
            }
        }
        actualStories.observeForever(observer)

        // Use LiveDataTestUtil to wait for data
        actualStories.getOrAwaitValue()

        Assert.assertEquals(0, differ.snapshot().size)

        // Remove observer after test
        actualStories.removeObserver(observer)
    }

    @Test
    fun `when Get Stories Success Should Return Data`() = runTest {
        val storyList = DataDummy.generateDummyStoryResponse().listStory
        val data: PagingData<Story> = PagingData.from(storyList)
        val tempToken = "Bearer dummyToken"
        val expectedStories = MutableLiveData<PagingData<Story>>()
        expectedStories.value = data

        Mockito.`when`(apiService.getStories(tempToken, 1, 20)).thenReturn(StoryList(storyList))

        val mainViewModel = StoryViewModel(context, apiService)
        val actualStories = mainViewModel.getPagedStory { tempToken }

        val differ = AsyncPagingDataDiffer(
            diffCallback = HomeAdapter.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            mainDispatcher = Dispatchers.Main,
            workerDispatcher = Dispatchers.IO
        )

        val observer = Observer<PagingData<Story>> { pagingData ->
            GlobalScope.launch(Dispatchers.Main) {
                differ.submitData(pagingData)
            }
        }
        actualStories.observeForever(observer)

        // Use LiveDataTestUtil to wait for data
        actualStories.getOrAwaitValue()

        Assert.assertNotNull(actualStories.value)
        Assert.assertEquals(storyList.size, differ.snapshot().size)
        Assert.assertEquals(storyList[0], differ.snapshot()[0])

        // Remove observer after test
        actualStories.removeObserver(observer)
    }
}

val noopListUpdateCallback = object : ListUpdateCallback {
    override fun onInserted(position: Int, count: Int) {}
    override fun onRemoved(position: Int, count: Int) {}
    override fun onMoved(fromPosition: Int, toPosition: Int) {}
    override fun onChanged(position: Int, count: Int, payload: Any?) {}
}

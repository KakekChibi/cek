package com.example.storyapp.data.repository.remote

import android.util.Log
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.example.storyapp.data.model.Story

class QuotePagingSource(private val apiService: ApiService, private val token: String) : PagingSource<Int, Story>() {

    private companion object {
        const val INITIAL_PAGE_INDEX = 1
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Story> {
        return try {
            val position = params.key ?: INITIAL_PAGE_INDEX
            val response = apiService.getStories(token, position, params.loadSize).execute()

            if (response.isSuccessful) {
                val storyList = response.body()
                Log.d("QuotePagingSource", "Fetched stories: ${storyList?.listStory?.size}")
                LoadResult.Page(
                    data = storyList?.listStory ?: emptyList(),
                    prevKey = if (position == INITIAL_PAGE_INDEX) null else position - 1,
                    nextKey = if (storyList?.listStory?.isEmpty() == true) null else position + 1
                )
            } else {
                Log.e("QuotePagingSource", "Failed to fetch stories: ${response.errorBody()?.string()}")
                LoadResult.Error(Exception("Failed to fetch stories: ${response.errorBody()?.string()}"))
            }
        } catch (exception: Exception) {
            Log.e("QuotePagingSource", "Exception: ${exception.message}")
            LoadResult.Error(exception)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, Story>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            val anchorPage = state.closestPageToPosition(anchorPosition)
            anchorPage?.prevKey?.plus(1) ?: anchorPage?.nextKey?.minus(1)
        }
    }
}
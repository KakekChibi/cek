package com.example.storyapp.data.model

import com.google.gson.annotations.SerializedName

data class StoryList(
	@SerializedName("listStory")
	val listStory: List<Story>,

	@SerializedName("error")
	val error: Boolean,

	@SerializedName("message")
	val message: String
)

package com.example.storyapp.ui.dashboard.home

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.storyapp.R
import com.example.storyapp.data.viewmodel.SettingViewModel
import com.example.storyapp.data.viewmodel.StoryViewModel
import com.example.storyapp.data.viewmodel.ViewModelStoryFactory
import com.example.storyapp.data.viewmodel.ViewModelSettingFactory
import com.example.storyapp.databinding.FragmentHomeBinding
import com.example.storyapp.ui.dashboard.MainActivity
//import com.example.storyapp.ui.maps.ExploreFragment
import com.example.storyapp.ui.maps.MapsFragment
import com.example.storyapp.utils.Constanta
import com.example.storyapp.utils.Helper
import com.example.storyapp.utils.SettingPreferences
import com.example.storyapp.utils.dataStore
import java.util.*
import kotlin.concurrent.schedule

class HomeFragment : Fragment(), SwipeRefreshLayout.OnRefreshListener {

    private var viewModel: StoryViewModel? = null
    private lateinit var binding: FragmentHomeBinding
    private val rvAdapter = HomeAdapter()
    private var tempToken = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        viewModel = ViewModelProvider(
            this,
            ViewModelStoryFactory((activity as MainActivity))
        )[StoryViewModel::class.java]
        val pref = SettingPreferences.getInstance((activity as MainActivity).dataStore)
        val settingViewModel =
            ViewModelProvider(this, ViewModelSettingFactory(pref))[SettingViewModel::class.java]
        settingViewModel.getUserPreferences(Constanta.UserPreferences.UserToken.name)
            .observe(viewLifecycleOwner) { token ->
                tempToken = StringBuilder("Bearer ").append(token).toString()
                viewModel?.loadStoryData(tempToken)
            }
        (activity as AppCompatActivity).setSupportActionBar(binding.toolbar)

        binding.btnJumpUp.visibility = View.GONE
        binding.swipeRefresh.setOnRefreshListener {
            onRefresh()
        }
        binding.rvStory.apply {
            setHasFixedSize(true)
            layoutManager = LinearLayoutManager(context)
            isNestedScrollingEnabled = false
            adapter = rvAdapter
        }
        viewModel?.apply {
            loading.observe(viewLifecycleOwner) { binding.loading.root.visibility = it }
            error.observe(
                viewLifecycleOwner
            ) { if (it.isNotEmpty()) Helper.showDialogInfo(requireContext(), it) }
            storyList.observe(viewLifecycleOwner) {
                rvAdapter.apply {
                    initData(it)
                    notifyDataSetChanged()
                }
                binding.btnJumpUp.visibility = View.VISIBLE
            }
        }
        binding.btnJumpUp.setOnClickListener {
            binding.nestedScrollView.smoothScrollTo(0, 0)
        }
        return binding.root
    }

    override fun onRefresh() {
        binding.swipeRefresh.isRefreshing = true
//        viewModel?.loadStoryData(tempToken)
        Timer().schedule(2000) {
            binding.swipeRefresh.isRefreshing = false
        }
        binding.nestedScrollView.smoothScrollTo(0, 0)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.activity_main_toolbar, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.navigation_map -> {
                navigateToMapsFragment()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun navigateToMapsFragment() {
        val mapsFragment = MapsFragment()
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.container, mapsFragment)
            .addToBackStack(null)
            .commit()
    }
}
